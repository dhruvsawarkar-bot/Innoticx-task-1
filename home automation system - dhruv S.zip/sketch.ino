#include "DHT.h"

// Pin Definitions
#define DHTPIN 15
#define DHTTYPE DHT22
#define PIR_PIN 13
#define RELAY_LIGHT 2
#define RELAY_FAN 4

DHT dht(DHTPIN, DHTTYPE);

void setup() {
  Serial.begin(115200);
  
  // Initialize Pins
  pinMode(PIR_PIN, INPUT);
  pinMode(RELAY_LIGHT, OUTPUT);
  pinMode(RELAY_FAN, OUTPUT);

  // Set Relays to OFF initially (Most are Active Low, so HIGH = OFF)
  digitalWrite(RELAY_LIGHT, HIGH);
  digitalWrite(RELAY_FAN, HIGH);

  dht.begin();
  Serial.println("Home Automation System Booting...");
}

void loop() {
  // 1. Temperature & Humidity Logic
  float temp = dht.readTemperature();
  float hum = dht.readHumidity();

  if (isnan(temp) || isnan(hum)) {
    Serial.println("Failed to read from DHT sensor!");
  } else {
    Serial.print("Temp: "); Serial.print(temp); Serial.print("°C | ");
    Serial.print("Humidity: "); Serial.print(hum); Serial.println("%");

    // Threshold logic for Fan (Relay 2)
    if (temp > 30.0) {
      digitalWrite(RELAY_FAN, HIGH); // Turn Fan ON
      Serial.println(">> High Temp! Fan ON");
    } else {
      digitalWrite(RELAY_FAN, LOW);
      Serial.println(">> Low Temp! Fan OFF"); // Turn Fan OFF
    }
  }

  // 2. Motion Sensing Logic (Relay 1)
  int motion = digitalRead(PIR_PIN);
  if (motion == HIGH) {
    digitalWrite(RELAY_LIGHT, HIGH); // Turn Light ON
    Serial.println(">> Motion Detected! Light ON");
  } else {
    digitalWrite(RELAY_LIGHT, LOW);
    Serial.println(">> Motion NOT Detected! Light OFF"); // Turn Light OFF
  }

  // Add a small delay for stability
  delay(2000); 
}