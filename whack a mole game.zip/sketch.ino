#include <LiquidCrystal_I2C.h>

LiquidCrystal_I2C lcd(0x27,16,2);

int rowPins[4] = {6,7,8,9};
int colPins[4] = {2,3,4,5};
int buttonPins[4] = {10,11,12,13};

int targetRow;
int targetCol;

int score = 0;
int wrongCount = 0;

unsigned long startTime;
int ledTime = 1500;   // LED active time in milliseconds

void setup(){
  lcd.init();
  lcd.backlight();

  for(int i=0;i<4;i++){
    pinMode(rowPins[i],OUTPUT);
    pinMode(colPins[i],OUTPUT);
    pinMode(buttonPins[i],INPUT_PULLUP);
  }

  randomSeed(analogRead(A0));
  lcd.setCursor(0,0);
  lcd.print("Score:0");

  newLED();
}

void newLED(){
  // Turn OFF all LEDs
  for(int r=0;r<4;r++) digitalWrite(rowPins[r],HIGH);
  for(int c=0;c<4;c++) digitalWrite(colPins[c],LOW);

  // Select random LED
  targetRow = random(0,4);
  targetCol = random(0,4);

  digitalWrite(rowPins[targetRow],LOW);
  digitalWrite(colPins[targetCol],HIGH);

  startTime = millis();
}

void loop(){
  // Check button presses
  for(int i=0;i<4;i++){
    if(digitalRead(buttonPins[i]) == LOW){
      delay(30);
      if(digitalRead(buttonPins[i]) == LOW){
        // Update score automatically
        if(i == targetRow) score++;
        else{
          score--;
          wrongCount++;
        }

        while(digitalRead(buttonPins[i]) == LOW); // wait for release

        // Check for game over
        if(wrongCount >= 3){
          lcd.clear();
          lcd.print("GAME OVER");
          lcd.setCursor(0,1);
          lcd.print("Score:");
          lcd.print(score);
          delay(2000);
          score = 0;
          wrongCount = 0;
          lcd.clear();
          lcd.print("Score:0");
        }
        else{
          lcd.clear();
          lcd.print("Score:");
          lcd.print(score);
        }

        newLED();
        return;
      }
    }
  }

  // Handle miss if time runs out
  if(millis() - startTime > ledTime){
    lcd.clear();
    lcd.print("MISS");
    delay(400);
    lcd.clear();
    lcd.print("Score:");
    lcd.print(score);

    newLED();
  }
}